﻿#3. Write a script which take file from the keyboard and print the even and odd numbers stored in it.
# The input file has the below structure:

$file = Read-Host "Please enter your file"
$content = Get-Content $file

$odd = @()
$even = @()

foreach ($l in $content){
    
    if($l % 2 -eq 0){
        $even+=$l
    }else{
        $odd+=$l
    }

}

Write-Host "Odd numbers: "$odd
Write-Host "Even numbers: "$even 